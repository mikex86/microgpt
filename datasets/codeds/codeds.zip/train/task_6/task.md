# Build terminal_recorder via Make

Clone the terminal_recorder repository and build it.
The link to the repository is https://github.com/mikex86/terminal_recorder.git
Build the project via Make.
