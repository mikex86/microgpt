# Build Velox

Clone the Velox repository and build it.
The link to the repository is https://github.com/mikex86/Velox.git
Consult the README.md file for instructions on how to build the project.